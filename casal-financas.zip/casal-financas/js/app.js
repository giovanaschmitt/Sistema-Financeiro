// app.js - Lógica principal do app financeiro do casal
document.addEventListener('DOMContentLoaded', () => {

// --- Estado global ---
let state = {
  tela: 'inicio',
  mesAtual: new Date().getMonth(),
  anoAtual: new Date().getFullYear(),
  periodoGrafico: '6m',
  editandoTx: null,
  tipoForm: 'saida'
};

const MESES = ['Janeiro','Fevereiro','Março','Abril','Maio','Junho','Julho','Agosto','Setembro','Outubro','Novembro','Dezembro'];

// --- Navegação ---
function navegar(tela) {
  document.querySelectorAll('.tela').forEach(t => t.classList.remove('ativa'));
  document.querySelectorAll('.nav-item').forEach(n => n.classList.remove('ativo'));
  document.getElementById('tela-' + tela)?.classList.add('ativa');
  document.querySelector(`.nav-item[data-tela="${tela}"]`)?.classList.add('ativo');
  state.tela = tela;
  if (tela === 'inicio') renderInicio();
  if (tela === 'transacoes') renderTransacoes();
  if (tela === 'graficos') renderGraficos();
  if (tela === 'config') renderConfig();
}

document.querySelectorAll('.nav-item[data-tela]').forEach(btn => {
  btn.addEventListener('click', () => navegar(btn.dataset.tela));
});

// --- Usuário switcher ---
function renderUserSwitcher(container) {
  const data = Storage.load();
  const ativo = data.usuarioAtivo;
  container.innerHTML = data.usuarios.map(u => `
    <button class="user-btn ${u.id === ativo ? 'ativo' : ''}" data-uid="${u.id}">
      <span class="avatar" style="background:${u.cor}">${u.nome[0].toUpperCase()}</span>
      ${u.nome}
    </button>
  `).join('');
  container.querySelectorAll('.user-btn').forEach(btn => {
    btn.addEventListener('click', () => {
      Storage.setUsuarioAtivo(btn.dataset.uid);
      renderUserSwitcher(container);
      if (state.tela === 'inicio') renderInicio();
      if (state.tela === 'transacoes') renderTransacoes();
    });
  });
}

// --- Tela Início ---
function renderInicio() {
  const data = Storage.load();
  const hoje = new Date();
  const resumo = Storage.getResumoMes(hoje.getMonth(), hoje.getFullYear());

  // Saldo
  const saldo = resumo.entradas - resumo.saidas;
  document.getElementById('saldo-valor').textContent = formatarMoeda(Math.abs(saldo));
  document.getElementById('saldo-valor').style.color = saldo >= 0 ? 'var(--text)' : 'var(--red)';
  document.getElementById('total-entradas').textContent = formatarMoeda(resumo.entradas);
  document.getElementById('total-saidas').textContent = formatarMoeda(resumo.saidas);
  document.getElementById('mes-nome').textContent = MESES[hoje.getMonth()];

  // Orçamento
  const orc = data.orcamentoMensal;
  const pct = orc > 0 ? Math.min((resumo.saidas / orc) * 100, 100) : 0;
  const fill = document.getElementById('orc-fill');
  if (fill) {
    fill.style.width = pct + '%';
    fill.className = 'orcamento-fill' + (pct >= 90 ? ' critico' : pct >= 70 ? ' alerta' : '');
  }
  const orcLabel = document.getElementById('orc-label');
  if (orcLabel) orcLabel.textContent = `${pct.toFixed(0)}% do orçamento (${formatarMoeda(orc)})`;

  // Últimas transações
  const txs = Storage.getTransacoes({ mes: hoje.getMonth(), ano: hoje.getFullYear() }).slice(0, 8);
  const lista = document.getElementById('lista-recentes');
  if (lista) renderListaTx(lista, txs, data);

  // User switcher
  renderUserSwitcher(document.getElementById('user-switcher-inicio'));
}

// --- Tela Transações ---
function renderTransacoes() {
  const data = Storage.load();
  document.getElementById('mes-label-tx').textContent = `${MESES[state.mesAtual]} ${state.anoAtual}`;
  const txs = Storage.getTransacoes({ mes: state.mesAtual, ano: state.anoAtual });
  const lista = document.getElementById('lista-transacoes');
  if (lista) renderListaTx(lista, txs, data);
  renderUserSwitcher(document.getElementById('user-switcher-tx'));
}

function renderListaTx(container, txs, data) {
  if (txs.length === 0) {
    container.innerHTML = `
      <div class="empty-state">
        <div class="empty-icon">💸</div>
        <p>Nenhuma transação<br>neste período</p>
      </div>`;
    return;
  }
  container.innerHTML = txs.map(tx => {
    const cat = data.categorias.find(c => c.id === tx.categoria) || { icone: '📦', nome: tx.categoria };
    const u = data.usuarios.find(u => u.id === tx.usuario);
    const dataFmt = new Date(tx.data + 'T12:00:00').toLocaleDateString('pt-BR', { day:'2-digit', month:'short' });
    const pgto = data.formasPagamento.find(f => f.id === tx.pagamento);
    return `
    <div class="tx-item" data-id="${tx.id}">
      <div class="tx-icone">${cat.icone}</div>
      <div class="tx-info">
        <div class="tx-desc">${tx.descricao}</div>
        <div class="tx-meta">
          <span class="tx-user-dot" style="background:${u?.cor || '#888'}"></span>
          ${u?.nome || ''} · ${dataFmt} · ${pgto?.icone || ''} ${pgto?.nome || tx.pagamento}
        </div>
      </div>
      <div class="tx-valor ${tx.tipo}">${tx.tipo === 'saida' ? '−' : '+'}${formatarMoeda(tx.valor)}</div>
    </div>`;
  }).join('');
  container.querySelectorAll('.tx-item').forEach(el => {
    el.addEventListener('click', () => abrirEditar(el.dataset.id));
  });
}

// --- Tela Gráficos ---
function renderGraficos() {
  const hoje = new Date();
  const resumo = Storage.getResumoMes(hoje.getMonth(), hoje.getFullYear());
  const data = Storage.load();

  // Donut categorias
  Charts.renderizarDonuts('chart-donut', resumo.porCategoria, data.categorias);

  // Legenda
  const total = resumo.saidas;
  const legenda = document.getElementById('cat-legenda');
  if (legenda) {
    const cores = ['#7C6AF7','#F77C6A','#6AF7C5','#F7D06A','#6AB4F7','#F76AB4','#A8F76A','#F7A86A'];
    const items = data.categorias
      .map((c, i) => ({ ...c, valor: resumo.porCategoria[c.id] || 0, cor: cores[i] }))
      .filter(c => c.valor > 0)
      .sort((a, b) => b.valor - a.valor);
    legenda.innerHTML = items.map(c => {
      const pct = total > 0 ? (c.valor / total * 100).toFixed(1) : 0;
      return `
        <div class="cat-item">
          <span class="cat-dot" style="background:${c.cor}"></span>
          <span>${c.icone}</span>
          <span class="cat-nome">${c.nome}</span>
          <div class="cat-bar-bg"><div class="cat-bar-fill" style="width:${pct}%;background:${c.cor}"></div></div>
          <span class="cat-pct">${pct}%</span>
        </div>`;
    }).join('');
  }

  // Histórico meses
  renderGraficoHistorico();
}

function renderGraficoHistorico() {
  const qtd = state.periodoGrafico === '3m' ? 3 : state.periodoGrafico === '6m' ? 6 : 12;
  const hoje = new Date();
  const meses = [];
  for (let i = qtd - 1; i >= 0; i--) {
    const d = new Date(hoje.getFullYear(), hoje.getMonth() - i, 1);
    const r = Storage.getResumoMes(d.getMonth(), d.getFullYear());
    meses.push({
      label: MESES[d.getMonth()].substr(0, 3),
      entradas: r.entradas,
      saidas: r.saidas
    });
  }
  Charts.renderizarBarras('chart-barras', meses);
  Charts.renderizarLinha('chart-linha', meses);
}

document.querySelectorAll('.periodo-tab').forEach(btn => {
  btn.addEventListener('click', () => {
    document.querySelectorAll('.periodo-tab').forEach(b => b.classList.remove('ativo'));
    btn.classList.add('ativo');
    state.periodoGrafico = btn.dataset.p;
    renderGraficoHistorico();
  });
});

// --- Navegação mês ---
document.getElementById('btn-mes-ant')?.addEventListener('click', () => {
  if (state.mesAtual === 0) { state.mesAtual = 11; state.anoAtual--; }
  else state.mesAtual--;
  renderTransacoes();
});
document.getElementById('btn-mes-prox')?.addEventListener('click', () => {
  const hoje = new Date();
  if (state.mesAtual === hoje.getMonth() && state.anoAtual === hoje.getFullYear()) return;
  if (state.mesAtual === 11) { state.mesAtual = 0; state.anoAtual++; }
  else state.mesAtual++;
  renderTransacoes();
});

// --- Modal Adicionar / Editar ---
const overlayForm = document.getElementById('overlay-form');
const formTx = document.getElementById('form-tx');

document.getElementById('btn-add-central').addEventListener('click', () => abrirForm());

function abrirForm(tx = null) {
  state.editandoTx = tx ? tx.id : null;
  state.tipoForm = tx ? tx.tipo : 'saida';

  const data = Storage.load();
  document.getElementById('sheet-title-form').textContent = tx ? 'Editar transação' : 'Nova transação';

  // Preencher selects
  const selCat = document.getElementById('sel-categoria');
  selCat.innerHTML = data.categorias.map(c => `<option value="${c.id}">${c.icone} ${c.nome}</option>`).join('');
  const selPgto = document.getElementById('sel-pagamento');
  selPgto.innerHTML = data.formasPagamento.map(f => `<option value="${f.id}">${f.icone} ${f.nome}</option>`).join('');
  const selUser = document.getElementById('sel-usuario');
  selUser.innerHTML = data.usuarios.map(u => `<option value="${u.id}">${u.nome}</option>`).join('');

  // Preencher valores
  if (tx) {
    document.getElementById('inp-descricao').value = tx.descricao;
    document.getElementById('inp-valor').value = tx.valor.toFixed(2).replace('.', ',');
    document.getElementById('inp-data').value = tx.data;
    selCat.value = tx.categoria;
    selPgto.value = tx.pagamento;
    selUser.value = tx.usuario;
  } else {
    formTx.reset();
    document.getElementById('inp-data').value = new Date().toISOString().split('T')[0];
    selUser.value = data.usuarioAtivo;
  }

  atualizarChipsTipo();
  document.getElementById('btn-deletar').style.display = tx ? 'block' : 'none';
  overlayForm.classList.add('aberta');
}

function abrirEditar(id) {
  const data = Storage.load();
  const tx = data.transacoes.find(t => t.id === id);
  if (tx) abrirForm(tx);
}

function fecharForm() { overlayForm.classList.remove('aberta'); }
document.getElementById('btn-fechar-form').addEventListener('click', fecharForm);
overlayForm.addEventListener('click', e => { if (e.target === overlayForm) fecharForm(); });

// Chips de tipo
document.querySelectorAll('.tipo-chip').forEach(btn => {
  btn.addEventListener('click', () => {
    state.tipoForm = btn.dataset.tipo;
    atualizarChipsTipo();
  });
});

function atualizarChipsTipo() {
  document.querySelectorAll('.tipo-chip').forEach(btn => {
    btn.className = 'tipo-chip';
    if (btn.dataset.tipo === state.tipoForm) {
      btn.classList.add(`ativo-${state.tipoForm}`);
    }
  });
}

// Submeter form
formTx.addEventListener('submit', e => {
  e.preventDefault();
  const valorRaw = document.getElementById('inp-valor').value.replace(',', '.');
  const valor = parseFloat(valorRaw);
  if (!valor || valor <= 0) { toast('Valor inválido'); return; }

  const tx = {
    descricao: document.getElementById('inp-descricao').value.trim() || 'Sem descrição',
    valor,
    tipo: state.tipoForm,
    data: document.getElementById('inp-data').value,
    categoria: document.getElementById('sel-categoria').value,
    pagamento: document.getElementById('sel-pagamento').value,
    usuario: document.getElementById('sel-usuario').value
  };

  if (state.editandoTx) {
    Storage.updateTransacao(state.editandoTx, tx);
    toast('Transação atualizada');
  } else {
    Storage.addTransacao(tx);
    toast('Transação salva');
  }

  fecharForm();
  if (state.tela === 'inicio') renderInicio();
  if (state.tela === 'transacoes') renderTransacoes();
});

// Deletar
document.getElementById('btn-deletar').addEventListener('click', () => {
  if (!state.editandoTx) return;
  if (!confirm('Excluir esta transação?')) return;
  Storage.deleteTransacao(state.editandoTx);
  toast('Transação excluída');
  fecharForm();
  if (state.tela === 'inicio') renderInicio();
  if (state.tela === 'transacoes') renderTransacoes();
});

// --- OCR Cupom ---
const overlayOcr = document.getElementById('overlay-ocr');
document.getElementById('btn-abrir-ocr').addEventListener('click', () => {
  overlayOcr.classList.add('aberta');
});
document.getElementById('btn-fechar-ocr').addEventListener('click', () => {
  overlayOcr.classList.remove('aberta');
});
overlayOcr.addEventListener('click', e => { if (e.target === overlayOcr) overlayOcr.classList.remove('aberta'); });

document.getElementById('inp-foto-cupom').addEventListener('change', async (e) => {
  const file = e.target.files[0];
  if (!file) return;
  await processarCupom(file);
  e.target.value = '';
});

async function processarCupom(file) {
  const loading = document.getElementById('ocr-loading');
  const zona = document.getElementById('ocr-zona');
  const preview = document.getElementById('ocr-result-preview');
  loading.classList.add('visivel');
  zona.style.display = 'none';
  preview.style.display = 'none';

  try {
    const resultado = await OCR.processarCupom(file);
    loading.classList.remove('visivel');

    if (resultado.erro) {
      toast('Não consegui ler o cupom. Preencha manualmente.');
      zona.style.display = '';
      overlayOcr.classList.remove('aberta');
      abrirForm();
      return;
    }

    // Preencher preview
    preview.style.display = 'block';
    preview.innerHTML = `
      <div class="ocr-preview">
        <strong>${resultado.estabelecimento || 'Estabelecimento'}</strong><br>
        Total: <strong>${formatarMoeda(resultado.total || 0)}</strong><br>
        Data: ${resultado.data ? new Date(resultado.data + 'T12:00:00').toLocaleDateString('pt-BR') : '—'}<br>
        ${resultado.itens?.length ? `${resultado.itens.length} item(ns) encontrado(s)` : ''}
      </div>
    `;

    // Fechar OCR e abrir form preenchido
    setTimeout(() => {
      overlayOcr.classList.remove('aberta');
      zona.style.display = '';
      preview.style.display = 'none';

      const data = Storage.load();
      const txPre = {
        id: null,
        descricao: resultado.estabelecimento || 'Compra',
        valor: resultado.total || 0,
        tipo: 'saida',
        data: resultado.data || new Date().toISOString().split('T')[0],
        categoria: resultado.categoria_sugerida || 'outros',
        pagamento: resultado.forma_pagamento_detectada || 'dinheiro',
        usuario: data.usuarioAtivo
      };
      abrirForm(txPre.id ? txPre : null);

      // Preencher campos manualmente após form abrir
      setTimeout(() => {
        document.getElementById('inp-descricao').value = txPre.descricao;
        document.getElementById('inp-valor').value = txPre.valor.toFixed(2).replace('.', ',');
        document.getElementById('inp-data').value = txPre.data;
        document.getElementById('sel-categoria').value = txPre.categoria;
        document.getElementById('sel-pagamento').value = txPre.pagamento;
        state.tipoForm = 'saida';
        atualizarChipsTipo();
      }, 50);

    }, 1000);

  } catch (err) {
    loading.classList.remove('visivel');
    zona.style.display = '';
    toast('Erro ao processar cupom');
    console.error(err);
  }
}

// --- Config ---
function renderConfig() {
  const data = Storage.load();
  document.getElementById('cfg-u1-nome').textContent = data.usuarios[0].nome;
  document.getElementById('cfg-u2-nome').textContent = data.usuarios[1].nome;
  document.getElementById('cfg-orcamento').textContent = formatarMoeda(data.orcamentoMensal);
}

// Editar nome usuários
document.getElementById('btn-editar-u1').addEventListener('click', () => editarNome('u1'));
document.getElementById('btn-editar-u2').addEventListener('click', () => editarNome('u2'));

function editarNome(uid) {
  const data = Storage.load();
  const u = data.usuarios.find(u => u.id === uid);
  const novo = prompt('Nome:', u.nome);
  if (novo?.trim()) {
    Storage.renomearUsuario(uid, novo.trim());
    renderConfig();
    toast('Nome atualizado');
  }
}

// Editar orçamento
document.getElementById('btn-editar-orcamento').addEventListener('click', () => {
  const data = Storage.load();
  const novo = prompt('Orçamento mensal (R$):', data.orcamentoMensal);
  const val = parseFloat(novo?.replace(',', '.'));
  if (!isNaN(val) && val >= 0) {
    Storage.setOrcamento(val);
    renderConfig();
    toast('Orçamento atualizado');
  }
});

// Exportar CSV
document.getElementById('btn-exportar').addEventListener('click', () => {
  const csv = Storage.exportarCSV();
  const blob = new Blob(['\uFEFF' + csv], { type: 'text/csv;charset=utf-8;' });
  const url = URL.createObjectURL(blob);
  const a = document.createElement('a');
  a.href = url;
  a.download = 'financas_casal.csv';
  a.click();
  URL.revokeObjectURL(url);
  toast('CSV exportado');
});

// Limpar dados
document.getElementById('btn-limpar').addEventListener('click', () => {
  if (!confirm('Apagar TODOS os dados? Esta ação não pode ser desfeita.')) return;
  localStorage.clear();
  toast('Dados apagados');
  setTimeout(() => location.reload(), 800);
});

// --- Utilitários ---
function formatarMoeda(v) {
  return 'R$\u00a0' + (v || 0).toLocaleString('pt-BR', { minimumFractionDigits: 2, maximumFractionDigits: 2 });
}

function toast(msg) {
  const el = document.getElementById('toast');
  el.textContent = msg;
  el.classList.add('visivel');
  clearTimeout(el._t);
  el._t = setTimeout(() => el.classList.remove('visivel'), 2400);
}

// --- Service Worker ---
if ('serviceWorker' in navigator) {
  navigator.serviceWorker.register('/sw.js').catch(() => {});
}

// --- Init ---
navegar('inicio');

});
