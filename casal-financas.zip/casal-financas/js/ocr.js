// ocr.js - Extração de dados de cupom fiscal via Claude Vision
window.OCR = {
  async processarCupom(imageFile) {
    return new Promise((resolve, reject) => {
      const reader = new FileReader();
      reader.onload = async (e) => {
        const base64 = e.target.result.split(',')[1];
        const mediaType = imageFile.type || 'image/jpeg';
        try {
          const result = await this._chamarClaude(base64, mediaType);
          resolve(result);
        } catch (err) {
          reject(err);
        }
      };
      reader.onerror = () => reject(new Error('Erro ao ler imagem'));
      reader.readAsDataURL(imageFile);
    });
  },

  async _chamarClaude(base64, mediaType) {
    const prompt = `Você é um assistente de extração de dados de cupons fiscais brasileiros.
Analise esta imagem de cupom fiscal e extraia as informações em JSON puro, sem markdown.

Retorne EXATAMENTE neste formato JSON:
{
  "estabelecimento": "nome do estabelecimento",
  "data": "YYYY-MM-DD",
  "total": 0.00,
  "itens": [
    { "descricao": "nome do item", "quantidade": 1, "valor": 0.00 }
  ],
  "categoria_sugerida": "uma dessas: alimentacao, transporte, saude, lazer, moradia, educacao, vestuario, outros",
  "forma_pagamento_detectada": "uma dessas se identificar: dinheiro, debito, credito, pix, boleto, ou null"
}

Se não conseguir identificar algum campo, use null. Para data, se não encontrar use a data de hoje.`;

    const response = await fetch('https://api.anthropic.com/v1/messages', {
      method: 'POST',
      headers: { 'Content-Type': 'application/json' },
      body: JSON.stringify({
        model: 'claude-sonnet-4-6',
        max_tokens: 1000,
        messages: [{
          role: 'user',
          content: [
            {
              type: 'image',
              source: { type: 'base64', media_type: mediaType, data: base64 }
            },
            { type: 'text', text: prompt }
          ]
        }]
      })
    });

    if (!response.ok) throw new Error('Erro na API de OCR');
    const data = await response.json();
    const texto = data.content?.find(c => c.type === 'text')?.text || '';
    
    try {
      const clean = texto.replace(/```json|```/g, '').trim();
      return JSON.parse(clean);
    } catch {
      return { erro: 'Não foi possível ler o cupom', texto_bruto: texto };
    }
  }
};
