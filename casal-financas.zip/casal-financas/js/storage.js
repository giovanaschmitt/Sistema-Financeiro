// storage.js - Gerenciamento de dados local com suporte a dois usuários
const DB_KEY = 'financas_casal_db';

const defaultData = {
  usuarios: [
    { id: 'u1', nome: 'Pessoa 1', cor: '#7C6AF7' },
    { id: 'u2', nome: 'Pessoa 2', cor: '#F77C6A' }
  ],
  usuarioAtivo: 'u1',
  transacoes: [],
  categorias: [
    { id: 'alimentacao', nome: 'Alimentação', icone: '🍽️' },
    { id: 'transporte', nome: 'Transporte', icone: '🚗' },
    { id: 'saude', nome: 'Saúde', icone: '💊' },
    { id: 'lazer', nome: 'Lazer', icone: '🎬' },
    { id: 'moradia', nome: 'Moradia', icone: '🏠' },
    { id: 'educacao', nome: 'Educação', icone: '📚' },
    { id: 'vestuario', nome: 'Vestuário', icone: '👕' },
    { id: 'outros', nome: 'Outros', icone: '📦' }
  ],
  formasPagamento: [
    { id: 'dinheiro', nome: 'Dinheiro', icone: '💵' },
    { id: 'debito', nome: 'Débito', icone: '💳' },
    { id: 'credito', nome: 'Crédito', icone: '💳' },
    { id: 'pix', nome: 'Pix', icone: '⚡' },
    { id: 'boleto', nome: 'Boleto', icone: '📄' }
  ],
  orcamentoMensal: 3000,
  meta: { nome: 'Reserva de emergência', valor: 10000, atual: 0 }
};

window.Storage = {
  load() {
    try {
      const raw = localStorage.getItem(DB_KEY);
      if (!raw) return this.save(defaultData), defaultData;
      const data = JSON.parse(raw);
      // merge categorias e formasPagamento se faltarem
      if (!data.categorias) data.categorias = defaultData.categorias;
      if (!data.formasPagamento) data.formasPagamento = defaultData.formasPagamento;
      return data;
    } catch { return defaultData; }
  },

  save(data) {
    localStorage.setItem(DB_KEY, JSON.stringify(data));
    return data;
  },

  getTransacoes(filtros = {}) {
    const data = this.load();
    let txs = [...data.transacoes];
    if (filtros.mes !== undefined) {
      txs = txs.filter(t => {
        const d = new Date(t.data);
        return d.getMonth() === filtros.mes && d.getFullYear() === filtros.ano;
      });
    }
    if (filtros.usuario) txs = txs.filter(t => t.usuario === filtros.usuario);
    return txs.sort((a, b) => new Date(b.data) - new Date(a.data));
  },

  addTransacao(tx) {
    const data = this.load();
    tx.id = 'tx_' + Date.now() + '_' + Math.random().toString(36).substr(2, 5);
    tx.criadoEm = new Date().toISOString();
    data.transacoes.push(tx);
    this.save(data);
    return tx;
  },

  updateTransacao(id, changes) {
    const data = this.load();
    const idx = data.transacoes.findIndex(t => t.id === id);
    if (idx >= 0) data.transacoes[idx] = { ...data.transacoes[idx], ...changes };
    this.save(data);
  },

  deleteTransacao(id) {
    const data = this.load();
    data.transacoes = data.transacoes.filter(t => t.id !== id);
    this.save(data);
  },

  getResumoMes(mes, ano) {
    const txs = this.getTransacoes({ mes, ano });
    const total = txs.reduce((s, t) => s + (t.tipo === 'saida' ? t.valor : -t.valor), 0);
    const porCategoria = {};
    const data = this.load();
    data.categorias.forEach(c => porCategoria[c.id] = 0);
    txs.filter(t => t.tipo === 'saida').forEach(t => {
      if (!porCategoria[t.categoria]) porCategoria[t.categoria] = 0;
      porCategoria[t.categoria] += t.valor;
    });
    const entradas = txs.filter(t => t.tipo === 'entrada').reduce((s, t) => s + t.valor, 0);
    const saidas = txs.filter(t => t.tipo === 'saida').reduce((s, t) => s + t.valor, 0);
    return { total, entradas, saidas, porCategoria, txs };
  },

  setUsuarioAtivo(id) {
    const data = this.load();
    data.usuarioAtivo = id;
    this.save(data);
  },

  renomearUsuario(id, nome) {
    const data = this.load();
    const u = data.usuarios.find(u => u.id === id);
    if (u) u.nome = nome;
    this.save(data);
  },

  setOrcamento(valor) {
    const data = this.load();
    data.orcamentoMensal = valor;
    this.save(data);
  },

  exportarCSV() {
    const data = this.load();
    const linhas = [['Data','Descrição','Valor','Tipo','Categoria','Pagamento','Usuário']];
    data.transacoes.forEach(t => {
      const u = data.usuarios.find(u => u.id === t.usuario);
      linhas.push([
        new Date(t.data).toLocaleDateString('pt-BR'),
        t.descricao,
        t.valor.toFixed(2).replace('.', ','),
        t.tipo === 'saida' ? 'Saída' : 'Entrada',
        t.categoria,
        t.pagamento,
        u ? u.nome : t.usuario
      ]);
    });
    return linhas.map(l => l.join(';')).join('\n');
  }
};
