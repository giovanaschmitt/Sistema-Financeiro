// charts.js - Gráficos financeiros
window.Charts = {
  instancias: {},

  cores: [
    '#7C6AF7', '#F77C6A', '#6AF7C5', '#F7D06A',
    '#6AB4F7', '#F76AB4', '#A8F76A', '#F7A86A'
  ],

  destruir(id) {
    if (this.instancias[id]) {
      this.instancias[id].destroy();
      delete this.instancias[id];
    }
  },

  renderizarDonuts(canvasId, porCategoria, categorias) {
    this.destruir(canvasId);
    const canvas = document.getElementById(canvasId);
    if (!canvas) return;

    const labels = [];
    const valores = [];
    const cores = [];

    categorias.forEach((cat, i) => {
      const v = porCategoria[cat.id] || 0;
      if (v > 0) {
        labels.push(cat.icone + ' ' + cat.nome);
        valores.push(v);
        cores.push(this.cores[i % this.cores.length]);
      }
    });

    if (valores.length === 0) {
      const ctx = canvas.getContext('2d');
      ctx.clearRect(0, 0, canvas.width, canvas.height);
      return;
    }

    this.instancias[canvasId] = new Chart(canvas, {
      type: 'doughnut',
      data: {
        labels,
        datasets: [{
          data: valores,
          backgroundColor: cores,
          borderWidth: 0,
          hoverOffset: 6
        }]
      },
      options: {
        responsive: true,
        maintainAspectRatio: true,
        cutout: '70%',
        plugins: {
          legend: {
            display: false
          },
          tooltip: {
            callbacks: {
              label: (ctx) => {
                const total = ctx.dataset.data.reduce((a, b) => a + b, 0);
                const pct = ((ctx.parsed / total) * 100).toFixed(1);
                return ` R$ ${ctx.parsed.toFixed(2).replace('.', ',')} (${pct}%)`;
              }
            },
            backgroundColor: '#1a1a1a',
            titleColor: '#fff',
            bodyColor: '#aaa',
            borderColor: '#333',
            borderWidth: 1
          }
        }
      }
    });
  },

  renderizarBarras(canvasId, dadosMeses) {
    this.destruir(canvasId);
    const canvas = document.getElementById(canvasId);
    if (!canvas) return;

    this.instancias[canvasId] = new Chart(canvas, {
      type: 'bar',
      data: {
        labels: dadosMeses.map(d => d.label),
        datasets: [
          {
            label: 'Entradas',
            data: dadosMeses.map(d => d.entradas),
            backgroundColor: '#6AF7C5',
            borderRadius: 6,
            borderSkipped: false
          },
          {
            label: 'Saídas',
            data: dadosMeses.map(d => d.saidas),
            backgroundColor: '#F77C6A',
            borderRadius: 6,
            borderSkipped: false
          }
        ]
      },
      options: {
        responsive: true,
        maintainAspectRatio: true,
        plugins: {
          legend: {
            labels: { color: '#888', font: { size: 11 }, boxWidth: 10, padding: 12 }
          },
          tooltip: {
            backgroundColor: '#1a1a1a',
            titleColor: '#fff',
            bodyColor: '#aaa',
            borderColor: '#333',
            borderWidth: 1,
            callbacks: {
              label: (ctx) => ` R$ ${ctx.parsed.y.toFixed(2).replace('.', ',')}`
            }
          }
        },
        scales: {
          x: {
            grid: { display: false },
            ticks: { color: '#666', font: { size: 11 } }
          },
          y: {
            grid: { color: '#1e1e1e' },
            ticks: {
              color: '#666',
              font: { size: 11 },
              callback: v => 'R$ ' + v.toLocaleString('pt-BR')
            }
          }
        }
      }
    });
  },

  renderizarLinha(canvasId, dadosMeses) {
    this.destruir(canvasId);
    const canvas = document.getElementById(canvasId);
    if (!canvas) return;

    this.instancias[canvasId] = new Chart(canvas, {
      type: 'line',
      data: {
        labels: dadosMeses.map(d => d.label),
        datasets: [{
          label: 'Saldo',
          data: dadosMeses.map(d => d.entradas - d.saidas),
          borderColor: '#7C6AF7',
          backgroundColor: 'rgba(124,106,247,0.08)',
          borderWidth: 2,
          pointBackgroundColor: '#7C6AF7',
          pointRadius: 4,
          fill: true,
          tension: 0.4
        }]
      },
      options: {
        responsive: true,
        maintainAspectRatio: true,
        plugins: {
          legend: { display: false },
          tooltip: {
            backgroundColor: '#1a1a1a',
            titleColor: '#fff',
            bodyColor: '#aaa',
            borderColor: '#333',
            borderWidth: 1,
            callbacks: {
              label: (ctx) => ` R$ ${ctx.parsed.y.toFixed(2).replace('.', ',')}`
            }
          }
        },
        scales: {
          x: {
            grid: { display: false },
            ticks: { color: '#666', font: { size: 11 } }
          },
          y: {
            grid: { color: '#1e1e1e' },
            ticks: {
              color: '#666',
              font: { size: 11 },
              callback: v => 'R$ ' + v.toLocaleString('pt-BR')
            }
          }
        }
      }
    });
  }
};
